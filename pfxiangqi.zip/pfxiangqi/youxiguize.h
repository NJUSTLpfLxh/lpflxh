#ifndef YOUXIGUIZE_H
#define YOUXIGUIZE_H

#include <QWidget>
#include <QPushButton>

class youxiguize : public QWidget
{
    Q_OBJECT
public:
    explicit youxiguize(QWidget *parent = nullptr);
    void sendsalotthree();
signals:
    void mysignal();                      //定义信号

public slots:
    void paintEvent(QPaintEvent *event);     //绘制
private:
    QPushButton b3;
};

#endif // YOUXIGUIZE_H
