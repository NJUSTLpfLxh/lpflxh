#include "juyuwang.h"
#include "youxidierchuangkou.h"
#include "playerbattleplayer.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>
#include <QMouseEvent>
juyuwang::juyuwang(QWidget *parent) : playerbattleplayer(parent)
{
    server=NULL;
    socket=NULL;
    //如果作为服务器端启动
    if(isserver==true)
    {
        server=new QTcpServer(this);
        server->listen(QHostAddress::Any,9777);//创建服务器

        connect(server,SIGNAL(newConnection()),this, SLOT(slotNewConnection()));
    }
    else
    {
        socket=new QTcpSocket(this);
        socket->connectToHost(QHostAddress("127.0.0.1"),9777);

        connect(socket,SIGNAL(readyRead()),this,SLOT(slotReceive()));
    }
    b6.setParent(this);
    this->setWindowTitle("欢迎来到局域网对战模式");
    b6.setText("返回到上一界面");
    connect(&b6,&QPushButton::clicked,this,&juyuwang::sendsalotsix);
    setFixedSize(800,800);
}

void juyuwang::mouseReleaseEvent(QMouseEvent *ev)
{
    QPoint pt=ev->pos();  //将pt转化为棋子的行列
    //判断这个行列有无棋子
    int row,column;
    if(!(gethanglie(pt,row,column)))
        return;                  //点击到了棋盘外面
    int clickedid=-1;     //被点击的棋子标号
    int i;
    //如果游戏已经结束，在选棋子时会提示游戏已经结束，无法选中棋子，请重开游戏
    if(gameover==true)
    {
            QMessageBox message(QMessageBox::Information, "提示", "本局游戏已结束，请重新开始.");
            message.setFont(QFont("宋体",16,QFont::Bold));
            message.exec();
            return;
    }
    for(i=0;i<32;i++){
        if(Q[i].row==row&&Q[i].column==column&&Q[i].die==false){  //棋子被选中了
            clickedid=i;
            break;
        }
    }
    if(selectedid==-1){
        if(clickedid!=-1){
            if(isredturn==Q[clickedid].red){
                selectedid=clickedid;
                update();
            }
        }
    } else{
        if(ifcanmove(selectedid,row,column,clickedid)){
            int r=Q[selectedid].row;
            int c=Q[selectedid].column;
            Q[selectedid].row=row;
            Q[selectedid].column=column;
            if(clickedid!=-1)                 //如果被点的地方有棋子就把他吃掉
                Q[clickedid].die=true;
            update();
            isredturn=!isredturn;
            winner(r,c,selectedid);
            selectedid=-1;
        }
    }
    char buf[3];
    buf[0]=selectedid;
    buf[1]=row;
    buf[2]=column;
    socket->write(buf,3);
}
void juyuwang::slotReceive()
{
    QByteArray array=socket->readAll();

    int id=array[0];
    int row=array[1];
    int column=array[2];

}

void juyuwang::slotNewConnection()
{
    //防止有第三个端口连接，socket不为空时，就直接return了
    if(socket) return;
    //nextPendingConnection建立连接
    socket=server->nextPendingConnection();
    //调试信息，如果应用程序输出出现connect，则表示连接成功。
    qDebug()<< "connect";
}
void juyuwang::sendsalotsix(){
    emit mysignal();
}
