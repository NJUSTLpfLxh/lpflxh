#include "youxidierchaungkou.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>

youxidierchaungkou::youxidierchaungkou(QWidget *parent) : QWidget(parent)
{
    b1.setParent(this);
    this->setWindowTitle("请选择游戏类型");
    b1.setText("返回到上一界面");
    connect(&b1,&QPushButton::clicked,this,&youxidierchaungkou::sendsalotone);
    setFixedSize(800,800);
    btn4=new QPushButton(this);
    btn4->setText("人人对战");
    btn4->move(500,100);
    btn4->setFixedSize(100,50);
    btn5=new QPushButton(this);
    btn5->setText("人机对战");
    btn5->move(500,200);
    btn5->setFixedSize(100,50);
    b1.move(450,300);
    b1.setFixedSize(200,50);
}

void youxidierchaungkou::sendsalotone(){
    emit mysignal();
}
