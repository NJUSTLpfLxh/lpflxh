#ifndef PLAYERBATTLEPLAYER_H
#define PLAYERBATTLEPLAYER_H

#include <QWidget>
#include <QPushButton>
#include <QPixmap>
#include "qizi.h"

class playerbattleplayer : public QWidget
{
    Q_OBJECT
public:
    explicit playerbattleplayer(QWidget *parent = nullptr);
    void sendsalotfour();

    int board_size=70;  //格子尺寸为70*70
    int chess_r=30;     //棋子半径为30

    QPoint center(int row,int column);
    QPoint center(int idno);

    int selectedid;    //被选择的棋子标号
    void drawqizi(QPainter& painter ,int idno);
    void paintEvent(QPaintEvent *event);
    void mouseReleaseEvent(QMouseEvent *ev);
    bool gethanglie(QPoint pt,int &row,int &column);  //坐标转换
    bool iscanmove(int moveid,int row,int column,int killid);   //判断能否走棋

    qizi Q[32];
signals:
    void mysignal();                      //定义信号
public slots:
private:
    QPushButton b4;
};

#endif // PLAYERBATTLEPLAYER_H
