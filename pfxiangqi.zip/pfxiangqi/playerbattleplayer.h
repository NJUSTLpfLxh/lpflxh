#ifndef PLAYERBATTLEPLAYER_H
#define PLAYERBATTLEPLAYER_H

#include <QWidget>
#include <QPushButton>
#include <QPixmap>

class playerbattleplayer : public QWidget
{
    Q_OBJECT
public:
    explicit playerbattleplayer(QWidget *parent = nullptr);
    void sendsalotfour();
signals:
    void mysignal();                      //定义信号
public slots:
    void paintEvent(QPaintEvent *event);     //绘制
private:
    QPushButton b4;
};

#endif // PLAYERBATTLEPLAYER_H
