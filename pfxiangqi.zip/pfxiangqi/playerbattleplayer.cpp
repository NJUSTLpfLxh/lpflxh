#include "playerbattleplayer.h"
#include "youxidierchuangkou.h"
#include "qizi.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>
#include <cmath>
#include <QMouseEvent>
#include <QRectF>
#include <QMessageBox>
playerbattleplayer::playerbattleplayer(QWidget *parent) : QWidget(parent)
{
    b4.setParent(this);
    this->setWindowTitle("欢迎来到人人对战模式");
    b4.setText("返回到上一界面");
    again.setParent(this);
    again.setText("重新游戏");
    again.move(300,0);
    connect(&b4,&QPushButton::clicked,this,&playerbattleplayer::sendsalotfour);
    connect(&again,&QPushButton::clicked,this,&playerbattleplayer::againgame);
    setFixedSize(800,800);
    setWindowIcon(QIcon(":/new/prefix1/text.jpg"));

    for(int i=0;i<32;i++){
        Q[i].init(i);
    }
    gameover=false;
    isredturn=true;
    selectedid=-1;
}
void playerbattleplayer::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPen pen=painter.pen();
    pen.setWidth(3);
    painter.setPen(pen);
    QFont font("楷体",25,QFont::Bold,false);

    //画横线
    for(int i=1;i<=10;i++)
        painter.drawLine(QPoint(board_size,i*board_size),QPoint(9*board_size,i*board_size));
    //画竖线
    painter.drawLine(QPoint(board_size,board_size),QPoint(board_size,10*board_size));
    for(int i=2;i<=8;i++){
        painter.drawLine(QPoint(i*board_size,board_size),QPoint(i*board_size,5*board_size));
        painter.drawLine(QPoint(i*board_size,6*board_size),QPoint(i*board_size,10*board_size));
    }
    painter.drawLine(QPoint(9*board_size,board_size),QPoint(9*board_size,10*board_size));
    //画九宫格
    painter.drawLine(QPoint(4*board_size,board_size),QPoint(6*board_size,3*board_size));
    painter.drawLine(QPoint(6*board_size,board_size),QPoint(4*board_size,3*board_size));
    painter.drawLine(QPoint(4*board_size,8*board_size),QPoint(6*board_size,10*board_size));
    painter.drawLine(QPoint(6*board_size,8*board_size),QPoint(4*board_size,10*board_size));
    //画定位线
    for(int i=1;i<=9;i++)
        for(int j=1;j<=10;j++){
            if(((j==3||j==8)&&(i==2||i==8))||((j==4||j==7)&&(i==3||i==5||i==7))){
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-0.3*board_size-6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-0.3*board_size-6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-6,j*board_size+0.3*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+0.3*board_size+6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+0.3*board_size+6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+6,j*board_size+0.3*board_size+6));
            }
            if(i==1&&(j==4||j==7)){
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+0.3*board_size+6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+0.3*board_size+6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+6,j*board_size+0.3*board_size+6));
            }
            if(i==9&&(j==4||j==7)){
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-0.3*board_size-6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-0.3*board_size-6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-6,j*board_size+0.3*board_size+6));
            }
        }
    //描绘“楚河汉界”
    font.setCapitalization(QFont::SmallCaps);  //设置字体大小
    font.setLetterSpacing(QFont::AbsoluteSpacing,0);  //设置字符间距离
    painter.setFont(font);  //使用字体
    painter.setPen(Qt::red);  //设置字体颜色
    painter.drawText(160,400,"楚河         汉界");
    //绘制棋子
    for(int i=0;i<32;i++){
        drawqizi(painter,i);
    }
}
bool playerbattleplayer::ifcanmove(int moveid, int row, int column, int killid){
    if(killid==-1){
        switch(Q[moveid].piece){
        case qizi::che:
            return ifcanmoveche(moveid,row,column);
        case qizi::ma:
            return ifcanmovema(moveid,row,column);
        case qizi::xiang:
            return ifcanmovexiang(moveid,row,column);
        case qizi::shi:
            return ifcanmoveshi(moveid,row,column);
        case qizi::pao:
            return ifcanmovepao(moveid,row,column,killid);
        case qizi::bing:
            return ifcanmovebing(moveid,row,column);
        case qizi::jiang:
            return ifcanmovejiang(moveid,row,column);
        }
    }
    else{
        if(Q[moveid].red==Q[killid].red){        //两颗棋子颜色相同
            selectedid=killid;       //换选择
            update();
            return false;
        }
        switch(Q[moveid].piece){
        case qizi::che:
            return ifcanmoveche(moveid,row,column);
        case qizi::ma:
            return ifcanmovema(moveid,row,column);
        case qizi::xiang:
            return ifcanmovexiang(moveid,row,column);
        case qizi::shi:
            return ifcanmoveshi(moveid,row,column);
        case qizi::pao:
            return ifcanmovepao(moveid,row,column,killid);
        case qizi::bing:
            return ifcanmovebing(moveid,row,column);
        case qizi::jiang:
            return ifcanmovejiang(moveid,row,column);
        }
    }
}
bool playerbattleplayer::ifcanmoveche(int moveid, int row, int column){
    //只能走直线
    int d_r=(Q[moveid].row-row);
    int d_c=(Q[moveid].column-column);
    if(d_r==0&&d_c<0){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row&&Q[i].column<column&&Q[i].column>Q[moveid].column&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==0&&d_c>0){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row&&Q[i].column>column&&Q[i].column<Q[moveid].column&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r>0&&d_c==0){
        for(int i=0;i<32;i++){
            if(Q[i].column==Q[moveid].column&&Q[i].row>row&&Q[i].row<Q[moveid].row&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r<0&&d_c==0){
        for(int i=0;i<32;i++){
            if(Q[i].column==Q[moveid].column&&Q[i].row<row&&Q[i].row>Q[moveid].row&&!Q[i].die) return false;
        }
        return true;
    }
    return false;
}
bool playerbattleplayer::ifcanmovema(int moveid, int row, int column){
    //判断走的格数
    int d_r=(Q[moveid].row-row);
    int d_c=(Q[moveid].column-column);
    //判断有没有棋子
    if(d_r==2&&d_c==-1){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row-1&&Q[i].column==Q[moveid].column&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==2&&d_c==1){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row-1&&Q[i].column==Q[moveid].column&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==-2&&d_c==-1){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row+1&&Q[i].column==Q[moveid].column&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==-2&&d_c==1){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row+1&&Q[i].column==Q[moveid].column&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==1&&d_c==2){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row&&Q[i].column==Q[moveid].column-1&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==-1&&d_c==2){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row&&Q[i].column==Q[moveid].column-1&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==1&&d_c==-2){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row&&Q[i].column==Q[moveid].column+1&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==-1&&d_c==-2){
        for(int i=0;i<32;i++){
            if(Q[i].row==Q[moveid].row&&Q[i].column==Q[moveid].column+1&&!Q[i].die) return false;
        }
        return true;
    }
    return false;
}
bool playerbattleplayer::ifcanmovexiang(int moveid, int row, int column){
    //判断是否在河界以内
    if(Q[moveid].red){
        if(row<5) return false;
    } else{
        if(row>4) return false;
    }
    //判断走的格数
    int d_r=(Q[moveid].row-row);
    int d_c=(Q[moveid].column-column);
    //判断有没有棋子
    if(d_r==-2&&d_c==-2){
        for(int i=0;i<32;i++){
            if(Q[i].row==row-1&&Q[i].column==column-1&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==-2&&d_c==2){
        for(int i=0;i<32;i++){
            if(Q[i].row==row-1&&Q[i].column==column+1&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==2&&d_c==-2){
        for(int i=0;i<32;i++){
            if(Q[i].row==row+1&&Q[i].column==column-1&&!Q[i].die) return false;
        }
        return true;
    }
    if(d_r==2&&d_c==2){
        for(int i=0;i<32;i++){
            if(Q[i].row==row+1&&Q[i].column==column+1&&!Q[i].die) return false;
        }
        return true;
    }
    return false;
}
bool playerbattleplayer::ifcanmoveshi(int moveid, int row, int column){
    //判断是否在九宫格内
    if(Q[moveid].red){
        if(row<=6) return false;
    } else{
        if(row>=3) return false;
    }
    if(column<=2) return false;
    if(column>=6) return false;
    //判断走的格数
    int d_r=abs(Q[moveid].row-row);
    int d_c=abs(Q[moveid].column-column);
    if(d_r==1&&d_c==1) return true;
    return false;
}
bool playerbattleplayer::ifcanmovepao(int moveid, int row, int column, int killid){
    if(killid!=-1){
        //只能走直线
        int d_r=(Q[moveid].row-row);
        int d_c=(Q[moveid].column-column);
        int count=0;
        if(d_r==0&&d_c<0){
            for(int i=0;i<32;i++){
                if(Q[i].row==Q[moveid].row&&Q[i].column<column&&Q[i].column>Q[moveid].column&&!Q[i].die) count++;
            }
            if(count==1) return true;
            return false;
        }
        if(d_r==0&&d_c>0){
            for(int i=0;i<32;i++){
                if(Q[i].row==Q[moveid].row&&Q[i].column>column&&Q[i].column<Q[moveid].column&&!Q[i].die) count++;
            }
            if(count==1) return true;
            return false;
        }
        if(d_r>0&&d_c==0){
            for(int i=0;i<32;i++){
                if(Q[i].column==Q[moveid].column&&Q[i].row>row&&Q[i].row<Q[moveid].row&&!Q[i].die) count++;
            }
            if(count==1) return true;
            return false;
        }
        if(d_r<0&&d_c==0){
            for(int i=0;i<32;i++){
                if(Q[i].column==Q[moveid].column&&Q[i].row<row&&Q[i].row>Q[moveid].row&&!Q[i].die) count++;
            }
            if(count==1) return true;
            return false;
        }
        return false;
    }
    else return ifcanmoveche(moveid,row,column);
}
bool playerbattleplayer::ifcanmovebing(int moveid, int row, int column){
    if(Q[moveid].red){
        if(Q[moveid].row>4){
            int d_r=(Q[moveid].row-row);
            int d_c=(Q[moveid].column-column);
            if(d_r==1&&d_c==0) return true;
            return false;
        }
        else{
            int d_r=(Q[moveid].row-row);
            int d_c=abs(Q[moveid].column-column);
            if((d_r==1&&d_c==0)||(d_r==0&&d_c==1)) return true;
            return false;
        }
    }
    else{
        if(Q[moveid].row<5){
            int d_r=(Q[moveid].row-row);
            int d_c=(Q[moveid].column-column);
            if(d_r==-1&&d_c==0) return true;
            return false;
        }
        else{
            int d_r=(Q[moveid].row-row);
            int d_c=abs(Q[moveid].column-column);
            if((d_r==-1&&d_c==0)||(d_r==0&&d_c==1)) return true;
            return false;
        }
    }
}
bool playerbattleplayer::ifcanmovejiang(int moveid, int row, int column){
    //判断是否在九宫格内
    if(Q[moveid].red){
        if(row<=6) return false;
    } else{
        if(row>=3) return false;
    }
    if(column<=2) return false;
    if(column>=6) return false;
    //判断走的格数
    int d_r=abs(Q[moveid].row-row);
    int d_c=abs(Q[moveid].column-column);
    if((d_r==1&&d_c==0)||(d_r==0&&d_c==1)) return true;
    return false;
}
void playerbattleplayer::mouseReleaseEvent(QMouseEvent *ev){
    QPoint pt=ev->pos();  //将pt转化为棋子的行列
    //判断这个行列有无棋子
    int row,column;
    if(!(gethanglie(pt,row,column)))
        return;                  //点击到了棋盘外面
    int clickedid=-1;     //被点击的棋子标号
    int i;
    //如果游戏已经结束，在选棋子时会提示游戏已经结束，无法选中棋子，请重开游戏
    if(gameover==true)
    {
            QMessageBox message(QMessageBox::Information, "提示", "本局游戏已结束，请重新开始.");
            message.setFont(QFont("宋体",16,QFont::Bold));
            message.exec();
            return;
    }
    for(i=0;i<32;i++){
        if(Q[i].row==row&&Q[i].column==column&&Q[i].die==false){  //棋子被选中了
            clickedid=i;
            break;
        }
    }
    if(selectedid==-1){
        if(clickedid!=-1){
            if(isredturn==Q[clickedid].red){
                selectedid=clickedid;
                update();
            }
        }
    } else{
        if(ifcanmove(selectedid,row,column,clickedid)){
            int r=Q[selectedid].row;
            int c=Q[selectedid].column;
            Q[selectedid].row=row;
            Q[selectedid].column=column;
            if(clickedid!=-1)                 //如果被点的地方有棋子就把他吃掉
                Q[clickedid].die=true;
            update();
            isredturn=!isredturn;
            winner(r,c,selectedid);
            selectedid=-1;
        }
    }
}
//（效率较低）找到点击位置行列
bool playerbattleplayer::gethanglie(QPoint pt, int &row, int &column){
    for(row=0;row<=9;row++){
        for(column=0;column<=8;column++){
            QPoint c=center(row,column);
            int len=sqrt((c.x()-pt.x())*(c.x()-pt.x())+(c.y()-pt.y())*(c.y()-pt.y()));
            if(len<=chess_r) return true;
        }
    }
    return false;
}
QPoint playerbattleplayer::center(int row, int column){
    QPoint ret;
    ret.rx()=(column+1)*board_size;
    ret.ry()=(row+1)*board_size;
    return ret;
}
QPoint playerbattleplayer::center(int idno){
    return center(Q[idno].row,Q[idno].column);
}
void playerbattleplayer::drawqizi(QPainter& painter,int idno){
    if(Q[idno].die)
        return ;

    QPoint c=center(idno);
    QRect rect=QRect(c.x()-chess_r,c.y()-chess_r,chess_r*2,chess_r*2);

    if(idno==selectedid){
        painter.setBrush(QBrush(QColor(0,128,255)));
        QRectF rect1((Q[idno].column+1)*board_size-chess_r,(Q[idno].row+1)*board_size-chess_r,chess_r*2,chess_r*2);
        painter.drawRect(rect1);
    }
    painter.setBrush(QBrush(QColor(128,64,0)));
    painter.setPen(Qt::black);
    painter.setRenderHint(QPainter::Antialiasing,true);  //抗锯齿
    painter.drawEllipse(center(Q[idno].idno),chess_r,chess_r);
    if(Q[idno].red)
         painter.setPen(Qt::red);
    else painter.setPen(Qt::black);
    painter.drawText(rect,Q[idno].getname(),QTextOption(Qt::AlignCenter));
}
void playerbattleplayer::winner(int a,int b,int moveid){
    int count=0;
    if(Q[4].die==true&&Q[20].die==false)
    {
        gameover=true;
        QMessageBox message(QMessageBox::Information, "提示", "本局结束，红方胜利.");
        message.setFont(QFont("宋体",16,QFont::Bold,false));
        message.exec();
    }
    else if(Q[4].die==false&&Q[20].die==true)
    {
        gameover=true;
        QMessageBox message(QMessageBox::Information, "提示", "本局结束，黑方胜利.");
        message.setFont(QFont("宋体",16,QFont::Bold,false));
        message.exec();
    } else if(Q[4].column==Q[20].column&&Q[4].column==b&&a<Q[20].row&&a>Q[4].row){
        for(int i=0;i<32;i++){
            if(Q[i].row<Q[20].row&&Q[i].row>Q[4].row&&Q[i].column==Q[4].column&&!Q[i].die) count++;
        }
        if(count==0){
            if(moveid<16){
                gameover=true;
                QMessageBox message(QMessageBox::Information, "提示", "本局结束，红方胜利.");
                message.setFont(QFont("宋体",16,QFont::Bold,false));
                message.exec();
            }
            else{
                gameover=true;
                QMessageBox message(QMessageBox::Information, "提示", "本局结束，黑方胜利.");
                message.setFont(QFont("宋体",16,QFont::Bold,false));
                message.exec();
            }
        }
    }
}
void playerbattleplayer::againgame(){
    for(int i=0;i<32;i++){
        Q[i].init(i);
    }
    gameover=false;
    isredturn=true;
    selectedid=-1;
    update();
}
void playerbattleplayer::sendsalotfour(){
    emit mysignal();
}
