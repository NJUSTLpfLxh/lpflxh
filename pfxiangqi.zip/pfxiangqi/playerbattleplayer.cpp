#include "playerbattleplayer.h"
#include "youxidierchuangkou.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>

playerbattleplayer::playerbattleplayer(QWidget *parent) : QWidget(parent)
{
    b4.setParent(this);
    this->setWindowTitle("欢迎来到人人对战模式");
    b4.setText("返回到上一界面");
    connect(&b4,&QPushButton::clicked,this,&playerbattleplayer::sendsalotfour);
    setFixedSize(800,800);
}

void playerbattleplayer::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPen pen=painter.pen();
    pen.setWidth(3);
    painter.setPen(pen);
    QFont font("楷体",25,QFont::Bold,true);
    int board_size=70;  //格子尺寸为70*70

    //画横线
    for(int i=1;i<=10;i++)
        painter.drawLine(QPoint(board_size,i*board_size),QPoint(9*board_size,i*board_size));
    //画竖线
    painter.drawLine(QPoint(board_size,board_size),QPoint(board_size,10*board_size));
    for(int i=2;i<=8;i++){
        painter.drawLine(QPoint(i*board_size,board_size),QPoint(i*board_size,5*board_size));
        painter.drawLine(QPoint(i*board_size,6*board_size),QPoint(i*board_size,10*board_size));
    }
    painter.drawLine(QPoint(9*board_size,board_size),QPoint(9*board_size,10*board_size));
    //画九宫格
    painter.drawLine(QPoint(4*board_size,board_size),QPoint(6*board_size,3*board_size));
    painter.drawLine(QPoint(6*board_size,board_size),QPoint(4*board_size,3*board_size));
    painter.drawLine(QPoint(4*board_size,8*board_size),QPoint(6*board_size,10*board_size));
    painter.drawLine(QPoint(6*board_size,8*board_size),QPoint(4*board_size,10*board_size));
    //画定位线
    for(int i=1;i<=9;i++)
        for(int j=1;j<=10;j++){
            if(((j==3||j==8)&&(i==2||i==8))||((j==4||j==7)&&(i==3||i==5||i==7))){
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-0.3*board_size-6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-0.3*board_size-6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-6,j*board_size+0.3*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+0.3*board_size+6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+0.3*board_size+6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+6,j*board_size+0.3*board_size+6));
            }
            if(i==1&&(j==4||j==7)){
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+0.3*board_size+6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+0.3*board_size+6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+6,j*board_size+0.3*board_size+6));
            }
            if(i==9&&(j==4||j==7)){
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-0.3*board_size-6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-0.3*board_size-6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-6,j*board_size+0.3*board_size+6));
            }
        }
    //描绘“楚河汉界”
    font.setCapitalization(QFont::SmallCaps);  //设置字体大小
    font.setLetterSpacing(QFont::AbsoluteSpacing,0);  //设置字符间距离
    painter.setFont(font);  //使用字体
    painter.setPen(Qt::red);  //设置字体颜色
    painter.drawText(160,400,"楚河         汉界");
}
void playerbattleplayer::sendsalotfour(){
    emit mysignal();
}
