#include "playerbattleplayer.h"
#include "youxidierchuangkou.h"
#include "qizi.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>
#include <cmath>
#include <QMouseEvent>
#include <QRectF>

playerbattleplayer::playerbattleplayer(QWidget *parent) : QWidget(parent)
{
    b4.setParent(this);
    this->setWindowTitle("欢迎来到人人对战模式");
    b4.setText("返回到上一界面");
    connect(&b4,&QPushButton::clicked,this,&playerbattleplayer::sendsalotfour);
    setFixedSize(800,800);

    for(int i=0;i<32;i++){
        Q[i].init(i);
    }
    selectedid=-1;
}
void playerbattleplayer::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPen pen=painter.pen();
    pen.setWidth(3);
    painter.setPen(pen);
    QFont font("楷体",25,QFont::Bold,false);

    //画横线
    for(int i=1;i<=10;i++)
        painter.drawLine(QPoint(board_size,i*board_size),QPoint(9*board_size,i*board_size));
    //画竖线
    painter.drawLine(QPoint(board_size,board_size),QPoint(board_size,10*board_size));
    for(int i=2;i<=8;i++){
        painter.drawLine(QPoint(i*board_size,board_size),QPoint(i*board_size,5*board_size));
        painter.drawLine(QPoint(i*board_size,6*board_size),QPoint(i*board_size,10*board_size));
    }
    painter.drawLine(QPoint(9*board_size,board_size),QPoint(9*board_size,10*board_size));
    //画九宫格
    painter.drawLine(QPoint(4*board_size,board_size),QPoint(6*board_size,3*board_size));
    painter.drawLine(QPoint(6*board_size,board_size),QPoint(4*board_size,3*board_size));
    painter.drawLine(QPoint(4*board_size,8*board_size),QPoint(6*board_size,10*board_size));
    painter.drawLine(QPoint(6*board_size,8*board_size),QPoint(4*board_size,10*board_size));
    //画定位线
    for(int i=1;i<=9;i++)
        for(int j=1;j<=10;j++){
            if(((j==3||j==8)&&(i==2||i==8))||((j==4||j==7)&&(i==3||i==5||i==7))){
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-0.3*board_size-6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-0.3*board_size-6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-6,j*board_size+0.3*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+0.3*board_size+6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+0.3*board_size+6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+6,j*board_size+0.3*board_size+6));
            }
            if(i==1&&(j==4||j==7)){
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+0.3*board_size+6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size-6),QPoint(i*board_size+6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+0.3*board_size+6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size+6,j*board_size+6),QPoint(i*board_size+6,j*board_size+0.3*board_size+6));
            }
            if(i==9&&(j==4||j==7)){
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-0.3*board_size-6,j*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size-6),QPoint(i*board_size-6,j*board_size-0.3*board_size-6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-0.3*board_size-6,j*board_size+6));
                painter.drawLine(QPoint(i*board_size-6,j*board_size+6),QPoint(i*board_size-6,j*board_size+0.3*board_size+6));
            }
        }
    //描绘“楚河汉界”
    font.setCapitalization(QFont::SmallCaps);  //设置字体大小
    font.setLetterSpacing(QFont::AbsoluteSpacing,0);  //设置字符间距离
    painter.setFont(font);  //使用字体
    painter.setPen(Qt::red);  //设置字体颜色
    painter.drawText(160,400,"楚河         汉界");
    //绘制棋子
    for(int i=0;i<32;i++){
        drawqizi(painter,i);
    }
}
bool playerbattleplayer::iscanmove(int moveid, int row, int column, int killid){
    if(killid==-1) return true;
    if(Q[moveid].red==Q[killid].red){        //两颗棋子颜色相同
        selectedid=killid;       //换选择
        update();
        return false;
    }
    return true;
}
void playerbattleplayer::mouseReleaseEvent(QMouseEvent *ev){
    QPoint pt=ev->pos();  //将pt转化为棋子的行列
    //判断这个行列有无棋子
    int row,column;
    if(!(gethanglie(pt,row,column)))
        return;                  //点击到了棋盘外面
    int clickedid=-1;     //被点击的棋子标号
    int i;
    for(i=0;i<32;i++){
        if(Q[i].row==row&&Q[i].column==column&&Q[i].die==false){  //棋子被选中了
            clickedid=i;
            break;
        }
    }        
    if(selectedid==-1){
        if(clickedid!=-1){
            selectedid=clickedid;
            update();
        }
    } else{
        if(iscanmove(selectedid,row,column,clickedid)){
            Q[selectedid].row=row;
            Q[selectedid].column=column;
            if(clickedid!=-1)                 //如果被点的地方有棋子就把他吃掉
                Q[clickedid].die=true;
            selectedid=-1;
            update();
        }
    }

}
bool playerbattleplayer::gethanglie(QPoint pt, int &row, int &column){
    for(row=0;row<=9;row++){
        for(column=0;column<=8;column++){
            QPoint c=center(row,column);
            int len=sqrt((c.x()-pt.x())*(c.x()-pt.x())+(c.y()-pt.y())*(c.y()-pt.y()));
            if(len<=chess_r) return true;
        }
    }
    return false;
}
QPoint playerbattleplayer::center(int row, int column){
    QPoint ret;
    ret.rx()=(column+1)*board_size;
    ret.ry()=(row+1)*board_size;
    return ret;
}
QPoint playerbattleplayer::center(int idno){
    return center(Q[idno].row,Q[idno].column);
}
void playerbattleplayer::drawqizi(QPainter& painter,int idno){
    if(Q[idno].die)
        return ;

    QPoint c=center(idno);
    QRect rect=QRect(c.x()-chess_r,c.y()-chess_r,chess_r*2,chess_r*2);

    if(idno==selectedid){
        painter.setBrush(QBrush(QColor(0,128,255)));
        QRectF rect1((Q[idno].column+1)*board_size-chess_r,(Q[idno].row+1)*board_size-chess_r,chess_r*2,chess_r*2);
        painter.drawRect(rect1);
    }
    painter.setBrush(QBrush(QColor(128,64,0)));
    painter.setPen(Qt::black);
    painter.setRenderHint(QPainter::Antialiasing,true);  //抗锯齿
    painter.drawEllipse(center(Q[idno].idno),chess_r,chess_r);
    if(Q[idno].red)
         painter.setPen(Qt::red);
    else painter.setPen(Qt::black);
    painter.drawText(rect,Q[idno].getname(),QTextOption(Qt::AlignCenter));
}
void playerbattleplayer::sendsalotfour(){
    emit mysignal();
}
