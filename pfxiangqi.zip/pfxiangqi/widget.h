#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPushButton>
#include "youxiguize.h"
#include "youxidierchuangkou.h"
#include <QTimer>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    void myslot();     //用于接受信号传过来的数据
    void changeone();   //实现第一个子窗口的显示以及窗口的隐藏
    void changethree();  //实现第二个子窗口的显示以及窗口的隐藏
    void dealone();   //实现第一个子窗口的隐藏以及窗口的显示
    void dealthree();         //实现第二个子窗口的隐藏以及窗口的显示

protected:

private slots:

private:
    Ui::Widget *ui;
    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;

    youxidierchuangkou w1;
    youxiguize w3;
};

#endif // WIDGET_H
