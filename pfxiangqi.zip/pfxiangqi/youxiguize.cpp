#include "youxiguize.h"
#include <QPainter>
#include <QPixmap>

youxiguize::youxiguize(QWidget *parent) : QWidget(parent)
{
    b3.setParent(this);
    this->setWindowTitle("游戏规则");
    b3.setText("返回到上一界面");
    connect(&b3,&QPushButton::clicked,this,&youxiguize::sendsalotthree);
    setFixedSize(800,1000);
}

void youxiguize::paintEvent(QPaintEvent *event){
    //绘制游戏规则
    QPainter painter(this);
    QFont font("楷体",15,QFont::Bold,true);
    //设置字体样式
    //font.setUnderline(true); //设置下划线
    //font.setOverline(true);  //设置上划线
    font.setCapitalization(QFont::SmallCaps);  //设置字体大小
    font.setLetterSpacing(QFont::AbsoluteSpacing,0);  //设置字符间距离
    painter.setFont(font);  //使用字体
    painter.setPen(Qt::black);  //设置字体颜色
    painter.drawText(40,60,"将（帅）：行走的步法为左、右横走，上、下竖走都行，但每次");
    painter.drawText(0,100,"只能行走一格。将和帅不准在同一直线上直接对面（中间无棋子）。");
    painter.drawText(40,140,"士（仕）：每行一步棋，只许沿着九宫中的斜线行走一步（方格的");
    painter.drawText(0,180,"对角线），行走方位可进、可退。");
    painter.drawText(40,220,"象（相）：此棋不能越过 河界走入对方的领地，其走法为：只能");
    painter.drawText(0,260,"斜走（两步），即俗称象（相）走田字，当象（相）行走的路线中，");
    painter.drawText(0,300,"及田字中心有棋子时，则不允许走过去。");
    painter.drawText(40,340,"车（車）：每行一步棋可以上、下直线行走（进、退）；左、右横");
    painter.drawText(0,380,"走，且行棋步数不限。");
    painter.drawText(40,420,"炮（砲）：此棋的行棋规则和车（車）类似，横平、竖直，只要前");
    painter.drawText(0,460,"方没有棋子的地方都能行走。它的吃棋规则很特别，必须跳过一个");
    painter.drawText(0,500,"棋子（无论是己方的还是对方的）去吃掉对方的一个棋子。");
    painter.drawText(40,540,"马（馬）：俗称：马走日字，如果在要去的方向，第一步直行处");
    painter.drawText(0,580,"（或者横行）有别的棋子挡住，则不许走过去（俗称：蹩马腿）。");
    painter.drawText(40,620,"卒（兵）：在没有过河界前，此棋每走一步棋只许向前直走一步（");
    painter.drawText(0,660,"不能后退）；过了河界之后，每行一步棋可以向前直走，或者横走（");
    painter.drawText(0,700,"左、右）一步，但也是不能后退的。");
    painter.drawText(40,740,"将死和困毙：");
    painter.drawText(0,780,"①一方的棋子攻击对方的将（帅），并在下一步要把它吃掉，称为照将");
    painter.drawText(0,820,"或简称将。照将不必声明。");
    painter.drawText(0,860,"②被照将的一方必须立即应将，即用自己的着法去化解被将的状态（而");
    painter.drawText(0,900,"不能应将不顾，而走其它的棋子）。");
    painter.drawText(0,940,"③如果被照将而无法应将，就算被将死（一方胜棋）。");
    painter.drawText(0,980,"④轮到走棋的一方，无子可走，就算被困毙（无棋可走这方为输棋）。");
    setWindowIcon(QIcon(":/new/prefix1/text.jpg"));

}
void youxiguize::sendsalotthree(){
    emit mysignal();
}
