#include "widget.h"
#include "ui_widget.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    //主窗口
    setWindowTitle("中国象棋");
    setFixedSize(800,800);

    //按钮的实现
    btn1=new QPushButton(this);
    btn1->setText("开始游戏");
    btn1->move(500,100);
    btn1->setFixedSize(100,50);
    btn2=new QPushButton(this);
    btn2->setText("退出游戏");
    btn2->move(500,200);
    btn2->setFixedSize(100,50);
    btn3=new QPushButton(this);
    btn3->setText("游戏规则");
    btn3->move(500,300);
    btn3->setFixedSize(100,50);

    //按钮信号的连接
    connect(btn1,&QPushButton::released,this,&Widget::changeone);
    connect(&w1,&youxidierchaungkou::mysignal,this,&Widget::dealone);
    connect(btn2,&QPushButton::pressed,this,&Widget::close);
    connect(btn3,&QPushButton::released,this,&Widget::changethree);
    connect(&w3,&youxiguize::mysignal,this,&Widget::dealthree);

}

void Widget::changeone(){
    w1.show();  //子窗口显示
    this->hide();  //本窗口隐藏
}
void Widget::dealone(){
    w1.hide();  //子窗口隐藏
    show();    //本窗口显示
}
void Widget::changethree(){
    w3.show();  //子窗口显示
    this->hide();  //本窗口隐藏
}
void Widget::dealthree(){
    w3.hide();  //子窗口隐藏
    show();    //本窗口显示
}
Widget::~Widget()
{
    delete ui;
}
