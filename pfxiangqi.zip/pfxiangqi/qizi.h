#ifndef QIZI_H
#define QIZI_H
#include <QString>

class qizi
{
public:
    qizi();
    //这里有一个析构函数，暂时没动什么意思 先不写
    //~qizi();

    enum NAME{che,ma,xiang,shi,pao,bing,jiang};

    int row;//棋子在第几行
    int column;//棋子在第几列
    int idno;//棋子的编号，总共32个棋子，编号为0~31
    bool die;//判断棋子是否被吃掉了
    bool red;//判断是红棋还是黑棋
    NAME piece;//棋子的名字，车，马，相，士，炮，兵，将。

    void init(int id){
        idno=id;
        die=false;
        if(id<16) red=false;
        else red=true;

        struct{
            int row,column;
            qizi::NAME piece;
        } pos[16]={
        {0,0,qizi::che},
        {0,1,qizi::ma},
        {0,2,qizi::xiang},
        {0,3,qizi::shi},
        {0,4,qizi::jiang},
        {0,5,qizi::shi},
        {0,6,qizi::xiang},
        {0,7,qizi::ma},
        {0,8,qizi::che},
        {2,1,qizi::pao},
        {2,7,qizi::pao},
        {3,0,qizi::bing},
        {3,2,qizi::bing},
        {3,4,qizi::bing},
        {3,6,qizi::bing},
        {3,8,qizi::bing},
        };

        if(id<16){
            row=pos[id].row;
            column=pos[id].column;
            piece=pos[id].piece;
        } else{
            row=9-pos[id-16].row;
            column=8-pos[id-16].column;
            piece=pos[id-16].piece;
        }
    }

    QString getname(){
        if(this->red){
            switch(this->piece){
            case che: return "車";
            case ma: return "馬";
            case xiang: return "相";
            case shi: return "仕";
            case pao: return "砲";
            case bing: return "兵";
            case jiang: return "帥";
            }
        } else {
            switch(this->piece){
            case che: return "車";
            case ma: return "馬";
            case xiang: return "象";
            case shi: return "士";
            case pao: return "炮";
            case bing: return "卒";
            case jiang: return "将";
            }
        }
  }

};

#endif // QIZI_H
