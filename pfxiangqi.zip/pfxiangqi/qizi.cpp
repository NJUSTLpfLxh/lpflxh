#include "qizi.h"

qizi::qizi()
{

}
