#ifndef YOUXIDIERCHAUNGKOU_H
#define YOUXIDIERCHAUNGKOU_H

#include <QWidget>
#include <QPushButton>

class youxidierchaungkou : public QWidget
{
    Q_OBJECT
public:
    explicit youxidierchaungkou(QWidget *parent = nullptr);
    void sendsalotone();
signals:
    void mysignal();                      //定义信号

public slots:
private:
    QPushButton b1;
    QPushButton *btn4;
    QPushButton *btn5;
};

#endif // YOUXIDIERCHAUNGKOU_H
