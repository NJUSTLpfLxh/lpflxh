#ifndef YOUXIDIERCHUANGKOU_H
#define YOUXIDIERCHUANGKOU_H

#include <QWidget>
#include <QPushButton>
#include "playerbattleplayer.h"
#include "playerbattleai.h"
#include "juyuwang.h"
class youxidierchuangkou : public QWidget
{
    Q_OBJECT
public:
    explicit youxidierchuangkou(QWidget *parent = nullptr);
    void sendsalotone();

    void myslot();     //用于接受信号传过来的数据
    void change();   //实现子窗口的显示以及窗口的隐藏
    void deal();   //实现子窗口的隐藏以及窗口的显示
    void change1();   //实现子窗口的显示以及窗口的隐藏
    void deal1();   //实现子窗口的隐藏以及窗口的显示
    void change2();   //实现子窗口的显示以及窗口的隐藏
    void deal2();   //实现子窗口的隐藏以及窗口的显示

signals:
    void mysignal();                      //定义信号
public slots:

private:
    QPushButton b1;
    QPushButton *btn4;
    QPushButton *btn5;
    QPushButton *btn6;

    playerbattleplayer w4;
    playerbattleai w5;
    juyuwang w6;
};

#endif // YOUXIDIERCHUANGKOU_H
