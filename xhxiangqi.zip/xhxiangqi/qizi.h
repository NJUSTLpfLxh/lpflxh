#ifndef QIZI_H
#define QIZI_H
#include <QString>

class qizi
{
public:
    qizi();
    //这里有一个析构函数，暂时没懂什么意思,先空着
    //~qizi();

    enum NAME{che,ma,xiang,shi,pao,bing,jiang};

    int row;//棋子在第几行
    int column;//棋子在第几列
    int idno;//棋子的编号，总共32个棋子，编号为0~31
    bool die;//判断棋子是否被吃掉了
    bool red;//判断是红棋还是黑棋
    NAME piece;//棋子的名字，车，马，相，士，炮，兵，将。

    void init(int id){
        idno=id;//初始化的棋子编号idno==形参id
        die=false;//初始化棋子未被吃掉
        if(id<16) red=false;//0~15号为黑棋
        else red=true;//16~31为白棋

        struct{
            int row,column;
            qizi::NAME piece;
        }
        pos[16]={
        {0,0,qizi::che},    //棋盘的第0行第0列为车
        {0,1,qizi::ma},     //棋盘的第0行第1列为马
        {0,2,qizi::xiang},  //棋盘的第0行第2列为象
        {0,3,qizi::shi},    //棋盘的第0行第3列为士
        {0,4,qizi::jiang},  //棋盘的第0行第4列为炮
        {0,5,qizi::shi},    //棋盘的第0行第5列为士
        {0,6,qizi::xiang},  //棋盘的第0行第6列为象
        {0,7,qizi::ma},     //棋盘的第0行第7列为马
        {0,8,qizi::che},    //棋盘的第0行第8列为车
        {2,1,qizi::pao},    //棋盘的第2行第1列为炮
        {2,7,qizi::pao},    //棋盘的第2行第7列为炮
        {3,0,qizi::bing},   //棋盘的第3行第0列为兵
        {3,2,qizi::bing},   //棋盘的第3行第2列为兵
        {3,4,qizi::bing},   //棋盘的第3行第4列为兵
        {3,6,qizi::bing},   //棋盘的第3行第6列为兵
        {3,8,qizi::bing},   //棋盘的第3行第8列为兵
        };

        //如果编号小于16，即从棋盘左上角的车开始放起，往右依次记录行列和棋子的名字
        if(id<16){
            row=pos[id].row;
            column=pos[id].column;
            piece=pos[id].piece;
        }
        //如果编号大于等于16，即从棋盘右下角的车开始放起，往左依次记录行列和棋子的名字
        else{
            row=9-pos[id-16].row;
            column=8-pos[id-16].column;
            piece=pos[id-16].piece;
        }
    }
    //得到棋子的名字函数
    QString getname(){
        if(this->red){
            switch(this->piece){
            case che: return "車";
            case ma: return "馬";
            case xiang: return "相";
            case shi: return "仕";
            case pao: return "砲";
            case bing: return "兵";
            case jiang: return "帥";
            }
        }
        else {
            switch(this->piece){
            case che: return "車";
            case ma: return "馬";
            case xiang: return "象";
            case shi: return "士";
            case pao: return "炮";
            case bing: return "卒";
            case jiang: return "将";
            }
        }
  }
};

#endif // QIZI_H
