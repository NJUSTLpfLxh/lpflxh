#ifndef PLAYERBATTLEAI_H
#define PLAYERBATTLEAI_H

#include <QWidget>

class playerbattleai : public QWidget
{
    Q_OBJECT
public:
    explicit playerbattleai(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // PLAYERBATTLEAI_H