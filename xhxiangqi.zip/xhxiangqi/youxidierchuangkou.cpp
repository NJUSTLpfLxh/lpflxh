#include "youxidierchuangkou.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>


youxidierchuangkou::youxidierchuangkou(QWidget *parent) : QWidget(parent)
{
    b1.setParent(this);
    this->setWindowTitle("请选择游戏类型");
    b1.setText("返回到上一界面");
    connect(&b1,&QPushButton::clicked,this,&youxidierchuangkou::sendsalotone);
    setFixedSize(800,800);
    btn4=new QPushButton(this);
    btn4->setText("人人对战");
    btn4->move(500,100);
    btn4->setFixedSize(100,50);
    btn5=new QPushButton(this);
    btn5->setText("人机对战");
    btn5->move(500,200);
    btn5->setFixedSize(100,50);
    b1.move(450,300);
    b1.setFixedSize(200,50);

    connect(btn4,&QPushButton::released,this,&youxidierchuangkou::change);
    connect(&w4,&playerbattleplayer::mysignal,this,&youxidierchuangkou::deal);
}

void youxidierchuangkou::change(){
    w4.show();  //子窗口显示
    this->hide();  //本窗口隐藏
}
void youxidierchuangkou::deal(){
    w4.hide();  //子窗口隐藏
    show();    //本窗口显示
}
void youxidierchuangkou::sendsalotone(){
    emit mysignal();
}
