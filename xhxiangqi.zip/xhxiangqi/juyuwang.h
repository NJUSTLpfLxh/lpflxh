#ifndef JUYUWANG_H
#define JUYUWANG_H

#include <QWidget>
#include <QPushButton>
#include <QPixmap>
#include <QTcpServer>
#include <QTcpSocket>
#include "playerbattleplayer.h"

/*
    (1)红方还是黑方，这个信号由服务器发出，由客户端接收，
    第一个字节固定是1，第二个字节是0或者1，0表示接收方走黑棋，1表示接收方走红棋
    （2）点击信息
    第一个字节固定为2，第二个字节是row，第三个字节是column，第四个字节是id（可能为-1）
*/

class juyuwang : public playerbattleplayer
{
    Q_OBJECT
public:
    explicit juyuwang(QWidget *parent=nullptr);
    void sendsalotsix();

    QTcpServer* server;
    QTcpSocket* socket;
    bool isserver;

    void mouseReleaseEvent(QMouseEvent *ev);

signals:
    void mysignal();                      //定义信号
public slots:
    void slotNewConnection();
    void slotReceive();
private:
    QPushButton b6;
};

#endif // JUYUWANG_H
