#include "juyuwang.h"
#include "youxidierchuangkou.h"
#include <QPushButton>
#include <QPainter>
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>


juyuwang::juyuwang(QWidget *parent) : playerbattleplayer(parent)
{
    server=NULL;
    socket=NULL;

    //弹出问题框“是否作为服务器启动”
    QMessageBox::StandardButton ret;
    ret=QMessageBox::question(NULL,"Server Or Socket","是否作为服务器启动（红方）");

    isserver=false;

    if(ret==QMessageBox::Yes)
    {
        isserver=true;
    }

    //如果作为服务器端启动
    if(isserver==true)
    {
        server=new QTcpServer(this);
        server->listen(QHostAddress::Any,9777);//创建服务器

        connect(server,SIGNAL(newConnection()),this, SLOT(slotNewConnection()));
    }
    else
    {
        socket=new QTcpSocket(this);
        socket->connectToHost(QHostAddress("127.0.0.1"),9777);

        connect(socket,SIGNAL(readyRead()),this,SLOT(slotReceive()));
    }



    b6.setParent(this);
    this->setWindowTitle("欢迎来到局域网对战模式");
    b6.setText("返回到上一界面");
    connect(&b6,&QPushButton::clicked,this,&juyuwang::sendsalotsix);
    setFixedSize(800,800);



}

void juyuwang::slotReceive()
{
    QByteArray array=socket->readAll();
    int nCheckedID = array[0];
    int nRow = array[1];
    int nCol = array[2];
}

void juyuwang::slotNewConnection()
{
    //防止有第三个端口连接，socket不为空时，就直接return了
    if(socket) return;
    //nextPendingConnection建立连接
    socket=server->nextPendingConnection();

    //qDebug()<< "connect";

}

//void juyuwang::mouseReleaseEvent(QMouseEvent *ev)
//{

//}


void juyuwang::sendsalotsix(){
    emit mysignal();
}
