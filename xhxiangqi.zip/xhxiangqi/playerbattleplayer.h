#ifndef PLAYERBATTLEPLAYER_H
#define PLAYERBATTLEPLAYER_H

#include <QWidget>
#include <QPushButton>
#include <QPixmap>
#include "qizi.h"

class playerbattleplayer : public QWidget
{
    Q_OBJECT
public:
    explicit playerbattleplayer(QWidget *parent = nullptr);
    void sendsalotfour();
    void againgame();  //重新游戏
    int board_size=70;  //格子尺寸为70*70
    int chess_r=30;     //棋子半径为30

    QPoint center(int row,int column);
    QPoint center(int idno);

    int selectedid;    //被选择的棋子标号
    bool gameover; //帅或将死亡，游戏结束
    bool isredturn;   //true为红方，false为黑方

    void drawqizi(QPainter& painter ,int idno);
    void paintEvent(QPaintEvent *event);
    void mouseReleaseEvent(QMouseEvent *ev);
    bool gethanglie(QPoint pt,int &row,int &column);  //坐标转换
    bool ifcanmove(int moveid,int row,int column,int killid);   //判断能否走棋
    bool ifcanmoveche(int moveid,int row,int column);   //判断che能否走棋
    bool ifcanmovema(int moveid,int row,int column);   //判断ma能否走棋
    bool ifcanmovexiang(int moveid,int row,int column);   //判断xiang能否走棋
    bool ifcanmoveshi(int moveid,int row,int column);   //判断shi能否走棋
    bool ifcanmovepao(int moveid,int row,int column,int killid);   //判断pao能否走棋
    bool ifcanmovebing(int moveid,int row,int column);   //判断bing能否走棋
    bool ifcanmovejiang(int moveid,int row,int column);   //判断jiang能否走棋
    void winner(int a,int b,int moveid);//判断哪一家获胜


    qizi Q[32];
signals:
    void mysignal();                      //定义信号
public slots:
private:
    QPushButton b4;
    QPushButton again;
};

#endif // PLAYERBATTLEPLAYER_H

