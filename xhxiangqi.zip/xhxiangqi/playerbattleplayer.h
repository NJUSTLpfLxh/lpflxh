#ifndef PLAYERBATTLEPLAYER_H
#define PLAYERBATTLEPLAYER_H

#include <QWidget>
#include <QPushButton>
#include <QPixmap>
#include <qizi.h>
#include <QPoint>

class playerbattleplayer : public QWidget
{
    Q_OBJECT
public:
    explicit playerbattleplayer(QWidget *parent = nullptr);
    int board_size=70;//棋盘一格的大小
    int chess_r=30;//棋子的半径

    qizi Q[32];//定义32个棋子

    QPoint center(int row, int column);

    QPoint center(int idno);

    void sendsalotfour();

    //在棋盘上画棋子，因为画棋子部分比较多，所以要另外写功能函数
    void drawqizi(QPainter& painter,int idno);


    void paintEvent(QPaintEvent *event);     //绘制
signals:
    void mysignal();                      //定义信号
public slots:
private:
    QPushButton b4;
};

#endif // PLAYERBATTLEPLAYER_H
