#ifndef CHOOSEWINDOW_H
#define CHOOSEWINDOW_H

#include <QWidget>
#include "juyuwang.h"
class choosewindow : public QWidget
{
    Q_OBJECT
public:
    explicit choosewindow(int choosegamemode,QWidget *parent = nullptr);
    ~choosewindow;

    int choosegamemode;
    juyuwang *clickicon;

signals:

public slots:
};

#endif // CHOOSEWINDOW_H
