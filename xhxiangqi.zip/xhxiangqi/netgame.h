#ifndef NETGAME_H
#define NETGAME_H

#include <QWidget>

class netgame : public QWidget
{
    Q_OBJECT
public:
    explicit netgame(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // NETGAME_H