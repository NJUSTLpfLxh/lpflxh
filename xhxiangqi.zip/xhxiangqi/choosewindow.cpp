#include "choosewindow.h"
#include "juyuwang.h"
#include <QMessageBox>

choosewindow::choosewindow(int _choosegamemode,QWidget *parent) : QWidget(parent)
{

}
