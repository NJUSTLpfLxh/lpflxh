#include "playerbattleai.h"

playerbattleai::playerbattleai(QWidget *parent) : QWidget(parent)
{

}
